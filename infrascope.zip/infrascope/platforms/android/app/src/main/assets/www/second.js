const firebaseConfig = {
  // Your Firebase configuration here
  apiKey: "AIzaSyB88O3N6ENJrnhzq-E1gFqheHx_RQjFi_0",
  authDomain: "d-pic-9f564.firebaseapp.com",
  databaseURL: "https://d-pic-9f564-default-rtdb.firebaseio.com",
  projectId: "d-pic-9f564",
  storageBucket: "d-pic-9f564.appspot.com",
  messagingSenderId: "124504372634",
  appId: "1:124504372634:web:b1cf6f43958caf5b3fb623",
  measurementId: "G-FX3FJLLBNV",
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);

// Reference to your Firebase Realtime Database
const database = firebase.database();

const contactForm = document.getElementById("contactForm");

contactForm.addEventListener("submit", (e) => {
  e.preventDefault(); // Prevent default form submission

  // Collect form data
  const formData = {
    "Weather Conditions": document.getElementById("Weather Conditions").value,
    emailid: document.getElementById("emailid").value,
    completionDate: document.getElementById("completionDate").value,
    completionStatus: document.getElementById("completionStatus").value,
    "Resource Utilizatio": document.getElementById("Resource Utilizatio").value,
    "Project Progress": document.getElementById("Project Progress").value,
    "Budget Data": document.getElementById("Budget Data").value,
    "Cost estimates": document.getElementById("Cost estimates").value,
    "actual costs": document.getElementById("actual costs").value,
    msgContent: document.getElementById("msgContent").value,
  };

  // Push the form data to Firebase
  const messagesRef = database.ref("contactMessages");
  messagesRef
    .push(formData)
    .then(() => {
      // Clear the form after successful submission
      contactForm.reset();
      // Show a success message or perform any other actions
      console.log("Form data submitted successfully!");
    })
    .catch((error) => {
      // Handle errors
      console.error("Error submitting form data:", error);
    });
});

firebase.initializeApp(firebaseConfig);

// Reference to your Firebase Storage
const storage = firebase.storage();
const storageRef = storage.ref();

// Handle image upload when the button is clicked
document.getElementById("uploadButton").addEventListener("click", function () {
  const file = document.getElementById("imageUpload").files[0];

  if (file) {
    const imagesRef = storageRef.child("images/" + file.name);

    // Upload the file to Firebase Storage
    imagesRef
      .put(file)
      .then(function (snapshot) {
        console.log("Image uploaded successfully!");
        alert("Image uploaded successfully!");
      })
      .catch(function (error) {
        console.error("Error uploading image:", error);
        alert("Error uploading image!");
      });
  } else {
    alert("Please select an image file!");
  }
});

// Replace the following with your Firebase configuration

// Initialize Firebase
firebase.initializeApp(firebaseConfig);

// Get references to Firebase services

// Function to handle image upload
function uploadImage() {
  const fileInput = document.getElementById("fileInput");
  const file = fileInput.files[0];

  if (file) {
    const storageRef = storage.ref("images/${file.name}");
    const uploadTask = storageRef.put(file);

    uploadTask.on(
      "state_changed",
      null,
      (error) => {
        // Handle unsuccessful uploads
        console.error("Error uploading image:", error);
      },
      () => {
        // Handle successful uploads - get the download URL and save it to the database
        uploadTask.snapshot.ref.getDownloadURL().then((downloadURL) => {
          saveImageToDatabase(file.name, downloadURL);
        });
      }
    );
  }
}

// Function to save image details to the database
function saveImageToDatabase(fileName, downloadURL) {
  database.ref("images").push({
    fileName: fileName,
    downloadURL: downloadURL,
  });
}

// Function to display images from the database
function displayImages() {
  const imageContainer = document.getElementById("imageContainer");

  database.ref("images").once("value", (snapshot) => {
    snapshot.forEach((childSnapshot) => {
      const image = childSnapshot.val();
      const imgElement = document.createElement("img");
      imgElement.src = image.downloadURL;
      imageContainer.appendChild(imgElement);
    });
  });
}

// Call the function to display images when the page loads
displayImages();


// JavaScript code to handle button click event
document.getElementById('navButton').addEventListener('click', function() {
  // Perform navigation or any action upon button click
  // For example, redirecting to another page
  window.location.href = 'img.html'; // Replace URL with desired destination
});
