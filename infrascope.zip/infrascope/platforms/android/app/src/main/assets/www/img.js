// Replace the following with your Firebase configuration
const firebaseConfig = {
  // Your Firebase configuration here
  apiKey: "AIzaSyB88O3N6ENJrnhzq-E1gFqheHx_RQjFi_0",
  authDomain: "d-pic-9f564.firebaseapp.com",
  databaseURL: "https://d-pic-9f564-default-rtdb.firebaseio.com",
  projectId: "d-pic-9f564",
  storageBucket: "d-pic-9f564.appspot.com",
  messagingSenderId: "124504372634",
  appId: "1:124504372634:web:b1cf6f43958caf5b3fb623",
  measurementId: "G-FX3FJLLBNV",
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);

// Get references to Firebase services
const storage = firebase.storage();
const database = firebase.database();

// Function to handle image upload
function uploadImage() {
  const fileInput = document.getElementById('fileInput');
  const file = fileInput.files[0];

  if (file) {
    const storageRef = storage.ref(`images/${file.name}`);
    const uploadTask = storageRef.put(file);

    uploadTask.on('state_changed',
      null,
      error => {
        // Handle unsuccessful uploads
        console.error('Error uploading image:', error);
      },
      () => {
        // Handle successful uploads - get the download URL and save it to the database
        uploadTask.snapshot.ref.getDownloadURL().then(downloadURL => {
          saveImageToDatabase(file.name, downloadURL);
        });
      }
    );
  }
}

// Function to save image details to the database
function saveImageToDatabase(fileName, downloadURL) {
  database.ref('images').push({
    fileName: fileName,
    downloadURL: downloadURL
  });
}

// Function to display images from the database
function displayImages() {
  const imageContainer = document.getElementById('imageContainer');

  database.ref('images').once('value', snapshot => {
    snapshot.forEach(childSnapshot => {
      const image = childSnapshot.val();
      const imgElement = document.createElement('img');
      imgElement.src = image.downloadURL;
      imageContainer.appendChild(imgElement);
    });
  });
}


